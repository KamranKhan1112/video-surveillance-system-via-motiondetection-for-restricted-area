from temboo.Library.Amazon.CloudDrive.Trash.AddToTrash import AddToTrash, AddToTrashInputSet, AddToTrashResultSet, AddToTrashChoreographyExecution
from temboo.Library.Amazon.CloudDrive.Trash.ListTrash import ListTrash, ListTrashInputSet, ListTrashResultSet, ListTrashChoreographyExecution
from temboo.Library.Amazon.CloudDrive.Trash.Restore import Restore, RestoreInputSet, RestoreResultSet, RestoreChoreographyExecution
